﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
namespace lab112
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
          
        }

        private void button4_Click(object sender, EventArgs e)
        {
            openFileDialog1.Multiselect = false;
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                textBox2.Text = Path.GetFileName(openFileDialog1.FileName);
                pictureBox1.ImageLocation = String.Format(Path.GetFullPath(openFileDialog1.FileName));
            }
            
            
        }
        public void BindData()
{


    try
    {
        DataTable dtData = new System.Data.DataTable();
        using (SqlConnection dbCon = new SqlConnection(@"Data Source=AIS110CL7-031;Initial Catalog=product ;User ID=sa;Password=bimcs"))
        {
            using (SqlCommand cmdGetData = new SqlCommand("Select * from product_info", dbCon))
            {
                if (dbCon.State == ConnectionState.Closed)
                    dbCon.Open();
                using (SqlDataReader drGetData = cmdGetData.ExecuteReader())
                {
                    dtData.Load(drGetData);
                    for (int iCount = 0; iCount < dtData.Rows.Count; iCount++)
                    {
                        DataGridViewRow row = (DataGridViewRow)dataGridView1.Rows[0].Clone();
                        row.Cells[0].Value = dtData.Rows[iCount][0];
                        row.Cells[1].Value = dtData.Rows[iCount][1];
                        row.Cells[2].Value = dtData.Rows[iCount][2];
                        row.Cells[3].Value = dtData.Rows[iCount][3];
                        row.Cells[4].Value = dtData.Rows[iCount][4];
                        byte[] storedImage = (byte[])dtData.Rows[iCount]["logo"];
                        Image newImage;
                        MemoryStream stream = new MemoryStream(storedImage);
                        newImage = Image.FromStream(stream);
                        row.Cells[5].Value = newImage;
                        dataGridView1.Rows.Add(row);
                        dataGridView1.Rows[iCount].Height = 100;
                    }
                    if (dataGridView1.Columns[1] is DataGridViewImageColumn)
                    {
                        ((DataGridViewImageColumn)dataGridView1.Columns[1]).ImageLayout = DataGridViewImageCellLayout.Stretch;

                    }
                    //dgvData.Columns[1].Width = 20;
                    //dgvData.Columns[1].Width = 90;
                    dataGridView1.AllowUserToAddRows = false;
                    dataGridView1.AutoGenerateColumns = false;
                }
            }
        }
    }


    catch (Exception ex)
    {
        
    }
}
        public byte[] GetImageData()
        {
            FileStream fsImageStream = new FileStream(openFileDialog1.FileName, FileMode.Open,
            FileAccess.Read);
            byte[] bImageData = new byte[fsImageStream.Length];
            fsImageStream.Read(bImageData, 0, System.Convert.ToInt32(fsImageStream.Length));
            fsImageStream.Close();
            return bImageData;
        }


        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection MyConnection = new SqlConnection(@"Data Source=AIS110CL7-031;Initial Catalog=product;User ID=sa;Password=bimcs");
            SqlCommand MyCommand;
            SqlDataReader MyDataReader;
            byte[] bImageData = GetImageData();
            String query = "INSERT INTO product_info(version,description,startdate,enddate,logo) VALUES(@version,@description,@startdate,@enddate,@logo)";
            using (SqlCommand command = new SqlCommand(query, MyConnection))
            {
                command.Parameters.AddWithValue("@version", textBox1.Text.ToString());
                command.Parameters.AddWithValue("@description", richTextBox1.Text.ToString());
                command.Parameters.AddWithValue("@startdate", dateTimePicker1.Text.ToString());
                command.Parameters.AddWithValue("@enddate", dateTimePicker2.Text.ToString());
                command.Parameters.AddWithValue("@logo", bImageData);
                MyConnection.Open();
                int result = command.ExecuteNonQuery();
                MyConnection.Close();
                // Check Error
                if (result < 0)
                    MessageBox.Show("Error inserting data into Database!");
                else
                    MessageBox.Show("Record Inserted!");
            }
            Form1_Load(sender, e);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            BindData();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            int row;
row = e.RowIndex;
 
 textBox1.Text = dataGridView1.Rows[row].Cells["version"].Value.ToString();
 richTextBox1.Text = dataGridView1.Rows[row].Cells["description"].Value.ToString();
 richTextBox1.Text = dataGridView1.Rows[row].Cells["startdate"].Value.ToString();
 richTextBox1.Text = dataGridView1.Rows[row].Cells["enddate"].Value.ToString();
 //pictureBox1.Image = (Image)dataGridView1.Rows[row].Cells["Logo"];


        }

     
}
}
